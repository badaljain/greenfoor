public interface PriceDecorator
{
    public abstract double cost();
}
